Bewaardvoorjou — Export van je levensverhaal
============================================

Dit archief bevat:
  transcripties/   — Volledige tekst van elk verhaal-fragment
  metadata/        — Metadata, vragen en notities in JSON-formaat
  media/           — Overzicht van audio- en video-opnames (bestanden zelf zijn niet inbegrepen
                     vanwege bestandsgrootte; neem contact op voor een volledige media-download)

Gegenereerd op: 10-06-2026 11:23 UTC
Journey: Testjournaal
